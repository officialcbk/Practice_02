# [Project Name]
Project 02

## Description

Module 2

## Author

Emmanuel Eze

## Assignment

Module 2 Project related to Data Types in Python


Discuss in your own words the importance of following predefined standards in software development.

Security: To assist guard against vulnerabilities, several standards contain security features.

Scalability: Expanding well-organized code becomes simpler as projects get bigger.

Compliance: In certain sectors, adhering to standards is necessary to stay out of trouble with the law.

Onboarding: New developers can learn and fit in with the team more easily when there are standards in place.



Discuss in your own words ways in which a software developer can employ ethical habits when writing code.

Preserve Privacy: Prior to using personal information, get consent and store it securely.

Be Inclusive: Use polite language and ensure that your program is accessible to all users.

Remain Open: Clearly outline your code and provide justification for your choices.

Verify for Bias: Make sure your algorithms are fair by testing them, and incorporate a variety of viewpoints throughout the development process.

Put Quality First: Write dependable, clear code and take quick action to fix any problems.


Describe the contents of the file(s) in this repository. You may wish to revisit this at or near the end of the assignment.
.gitignore- to keep files that dont need to be backed to the remore server
README.md- For writing important information
sfd_assignment_2 :This contains the python file

